<?php 
/*
#####################################################################################
#                     PHP BENCHMARK SCRIPT BY XTRAFFIC.PEP.VN                       #
#                                                                                   #
#  Author            : xTraffic.pep.vn                                              #
#  Date              : September 18, 2014                                           #
#  Website           : http://xtraffic.pep.vn/                                      #
#  Link Download     : https://bit.ly/php-benchmark-script-by-xtraffic-pep-vn       #
#                                                                                   #
#####################################################################################
*/


if(XTRAFFIC_DEBUG) {
	error_reporting(E_ALL);	//Notice all error
	ini_set('display_errors', 1);
} else {
	error_reporting(E_ALL);	//Notice all error
	ini_set('display_errors', 0);
}




$gbStringPatternTest = 'The quick brown fox jumps over the lazy dog. Benchmark Host PHP by xTraffic.pep.vn (http://blog-xtraffic.pep.vn/).
Special characters : ~`!@#$%^&*()_-+={[}]|:;"\'<,>./?
Numbers : 0123456789
Alphabet : abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ
HTML : <p></p><br /><br><br/>
Vietnamese : 
à á ạ ả ã â ầ ấ ậ ẩ ẫ ă ằ ắ ặ ẳ ẵ
è é ẹ ẻ ẽ ê ề ế ệ ể ễ
ì í ị ỉ ĩ
ò ó ọ ỏ õ ô ồ ố ộ ổ ỗ ơ ờ ớ ợ ở ỡ
ù ú ụ ủ ũ ư ừ ứ ự ử ữ
ỳ ý ỵ ỷ ỹ
đ

#####################################################################################
#                     PHP BENCHMARK SCRIPT BY XTRAFFIC.PEP.VN                       #
#                                                                                   #
#  Author            : xTraffic.pep.vn                                              #
#  Date              : September 18, 2014                                           #
#  Website           : http://xtraffic.pep.vn/                                      #	
#  Link Download     : https://bit.ly/php-benchmark-script-by-xtraffic-pep-vn       #
#                                                                                   #
#####################################################################################

';


$gbLipsumPatternTest = '

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam odio lorem, imperdiet at tempus in, convallis eget est. Suspendisse congue laoreet massa in facilisis. Suspendisse finibus metus mattis, venenatis erat ut, efficitur nunc. Pellentesque consequat convallis porta. In aliquam placerat molestie. Maecenas tempus metus eu purus vehicula ornare. Duis hendrerit mi non consequat malesuada. Nulla sed sem eu nulla tristique sollicitudin id nec elit. Nunc tincidunt at metus eget luctus. Vivamus ac euismod velit. Sed nec euismod velit, sit amet consectetur augue. Morbi congue mi elit, nec luctus mauris volutpat vel.

Mauris facilisis massa et nulla consectetur luctus. Curabitur vitae ex at dolor tristique porta. Maecenas laoreet massa quis lorem consequat blandit. Nullam magna neque, rutrum id leo et, rhoncus facilisis ipsum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean eget felis non justo fringilla viverra. Cras imperdiet molestie mi, in blandit ipsum lacinia quis. Aenean ultrices ex ac metus congue interdum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec porta nibh et velit consectetur tristique.

"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tempor nunc vitae elit vestibulum tincidunt. Proin elementum porttitor nisl, sed pellentesque ipsum sodales eu. Vivamus sagittis quam sapien, quis pretium lacus finibus eu. Proin a aliquam tortor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus est justo, blandit id arcu sit amet, rutrum vulputate ligula. Donec sodales vitae dolor nec mollis. Suspendisse tincidunt sed lorem tincidunt convallis. Nulla consectetur placerat porttitor.

Lorem Ipsum chỉ đơn giản là một đoạn văn bản giả, được dùng vào việc trình bày và dàn trang phục vụ cho in ấn. Lorem Ipsum đã được sử dụng như một văn bản chuẩn cho ngành công nghiệp in ấn từ những năm 1500, khi một họa sĩ vô danh ghép nhiều đoạn văn bản với nhau để tạo thành một bản mẫu văn bản. Đoạn văn bản này không những đã tồn tại năm thế kỉ, mà khi được áp dụng vào tin học văn phòng, nội dung của nó vẫn không hề bị thay đổi. Nó đã được phổ biến trong những năm 1960 nhờ việc bán những bản giấy Letraset in những đoạn Lorem Ipsum, và gần đây hơn, được sử dụng trong các ứng dụng dàn trang, như Aldus PageMaker.

Chúng ta vẫn biết rằng, làm việc với một đoạn văn bản dễ đọc và rõ nghĩa dễ gây rối trí và cản trở việc tập trung vào yếu tố trình bày văn bản. Lorem Ipsum có ưu điểm hơn so với đoạn văn bản chỉ gồm nội dung kiểu "Nội dung, nội dung, nội dung" là nó khiến văn bản giống thật hơn, bình thường hơn. Nhiều phần mềm thiết kế giao diện web và dàn trang ngày nay đã sử dụng Lorem Ipsum làm đoạn văn bản giả, và nếu bạn thử tìm các đoạn "Lorem ipsum" trên mạng thì sẽ khám phá ra nhiều trang web hiện vẫn đang trong quá trình xây dựng. Có nhiều phiên bản khác nhau đã xuất hiện, đôi khi do vô tình, nhiều khi do cố ý (xen thêm vào những câu hài hước hay thông tục).

Lorem Ipsum-ը տպագրության և տպագրական արդյունաբերության համար նախատեսված մոդելային տեքստ է: Սկսած 1500-ականներից` Lorem Ipsum-ը հանդիսացել է տպագրական արդյունաբերության ստանդարտ մոդելային տեքստ, ինչը մի անհայտ տպագրիչի կողմից տարբեր տառատեսակների օրինակների գիրք ստեղծելու ջանքերի արդյունք է: Այս տեքստը ոչ միայն կարողացել է գոյատևել հինգ դարաշրջան, այլև ներառվել է էլեկտրոնային տպագրության մեջ` մնալով էապես անփոփոխ: Այն հայտնի է դարձել 1960-ականներին Lorem Ipsum բովանդակող Letraset էջերի թողարկման արդյունքում, իսկ ավելի ուշ համակարգչային տպագրության այնպիսի ծրագրերի թողարկման հետևանքով, ինչպիսին է Aldus PageMaker-ը, որը ներառում է Lorem Ipsum-ի տարատեսակներ:

Lorem Ipsum është një tekst shabllon i industrisë së printimit dhe shtypshkronjave. Lorem Ipsum ka qenë teksti shabllon i industrisë që nga vitet 1500, kur një shtypës i panjohur morri një galeri shkrimesh dhe i ngatërroi për të krijuar një libër mostër. Teksti i ka mbijetuar jo vetëm pesë shekujve, por edhe kalimit në shtypshkrimin elektronik, duke ndenjur në thelb i pandryshuar. U bë i njohur në vitet 1960 me lëshimin e letrave \'Letraset\' që përmbanin tekstin Lorem Ipsum, e në kohët e fundit me aplikacione publikimi si Aldus PageMaker që përmbajnë versione të Lorem Ipsum.

هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا يوجد محتوى نصي، هنا يوجد محتوى نصي" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال "lorem ipsum" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.

Lorem Ipsum е елементарен примерен текст, използван в печатарската и типографската индустрия. Lorem Ipsum е индустриален стандарт от около 1500 година, когато неизвестен печатар взема няколко печатарски букви и ги разбърква, за да напечата с тях книга с примерни шрифтове. Този начин не само е оцелял повече от 5 века, но е навлязъл и в публикуването на електронни издания като е запазен почти без промяна. Популяризиран е през 60те години на 20ти век със издаването на Letraset листи, съдържащи Lorem Ipsum пасажи, популярен е и в наши дни във софтуер за печатни издания като Aldus PageMaker, който включва различни версии на Lorem Ipsum.

Lorem Ipsum és un text de farciment usat per la indústria de la tipografia i la impremta. Lorem Ipsum ha estat el text estàndard de la indústria des de l\'any 1500, quan un impressor desconegut va fer servir una galerada de text i la va mesclar per crear un llibre de mostres tipogràfiques. No només ha sobreviscut cinc segles, sinó que ha fet el salt cap a la creació de tipus de lletra electrònics, romanent essencialment sense canvis. Es va popularitzar l\'any 1960 amb el llançament de fulls Letraset que contenien passatges de Lorem Ipsum, i més recentment amb programari d\'autoedició com Aldus Pagemaker que inclou versions de Lorem Ipsum.

Lorem Ipsum je jednostavno probni tekst koji se koristi u tiskarskoj i slovoslagarskoj industriji. Lorem Ipsum postoji kao industrijski standard još od 16-og stoljeća, kada je nepoznati tiskar uzeo tiskarsku galiju slova i posložio ih da bi napravio knjigu s uzorkom tiska. Taj je tekst ne samo preživio pet stoljeća, već se i vinuo u svijet elektronskog slovoslagarstva, ostajući u suštini nepromijenjen. Postao je popularan tijekom 1960-ih s pojavom Letraset listova s odlomcima Lorem Ipsum-a, a u skorije vrijeme sa software-om za stolno izdavaštvo kao što je Aldus PageMaker koji također sadrži varijante Lorem Ipsum-a.

Lorem Ipsum je demonstrativní výplňový text používaný v tiskařském a knihařském průmyslu. Lorem Ipsum je považováno za standard v této oblasti už od začátku 16. století, kdy dnes neznámý tiskař vzal kusy textu a na jejich základě vytvořil speciální vzorovou knihu. Jeho odkaz nevydržel pouze pět století, on přežil i nástup elektronické sazby v podstatě beze změny. Nejvíce popularizováno bylo Lorem Ipsum v šedesátých letech 20. století, kdy byly vydávány speciální vzorníky s jeho pasážemi a později pak díky počítačovým DTP programům jako Aldus PageMaker.

Lorem Ipsum er ganske enkelt fyldtekst fra print- og typografiindustrien. Lorem Ipsum har været standard fyldtekst siden 1500-tallet, hvor en ukendt trykker sammensatte en tilfældig spalte for at trykke en bog til sammenligning af forskellige skrifttyper. Lorem Ipsum har ikke alene overlevet fem århundreder, men har også vundet indpas i elektronisk typografi uden væsentlige ændringer. Sætningen blev gjordt kendt i 1960\'erne med lanceringen af Letraset-ark, som indeholdt afsnit med Lorem Ipsum, og senere med layoutprogrammer som Aldus PageMaker, som også indeholdt en udgave af Lorem Ipsum.

Lorem Ipsum is slechts een proeftekst uit het drukkerij- en zetterijwezen. Lorem Ipsum is de standaard proeftekst in deze bedrijfstak sinds de 16e eeuw, toen een onbekende drukker een zethaak met letters nam en ze door elkaar husselde om een font-catalogus te maken. Het heeft niet alleen vijf eeuwen overleefd maar is ook, vrijwel onveranderd, overgenomen in elektronische letterzetting. Het is in de jaren \'60 populair geworden met de introductie van Letraset vellen met Lorem Ipsum passages en meer recentelijk door desktop publishing software zoals Aldus PageMaker die versies van Lorem Ipsum bevatten.

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

Lorem Ipsum on lihtsalt proovitekst, mida kasutatakse printimis- ja ladumistööstuses. See on olnud tööstuse põhiline proovitekst juba alates 1500. aastatest, mil tundmatu printija võttis hulga suvalist teksti, et teha trükinäidist. Lorem Ipsum ei ole ainult viis sajandit säilinud, vaid on ka edasi kandunud elektroonilisse trükiladumisse, jäädes sealjuures peaaegu muutumatuks. See sai tuntuks 1960. aastatel Letraset\'i lehtede väljalaskmisega, ja hiljuti tekstiredaktoritega nagu Aldus PageMaker, mis sisaldavad erinevaid Lorem Ipsumi versioone.

Lorem Ipsum on yksinkertaisesti testausteksti, jota tulostus- ja ladontateollisuudet käyttävät. Lorem Ipsum on ollut teollisuuden normaali testausteksti jo 1500-luvulta asti, jolloin tuntematon tulostaja otti kaljuunan ja sekoitti sen tehdäkseen esimerkkikirjan. Se ei ole selvinnyt vain viittä vuosisataa, mutta myös loikan elektroniseen kirjoitukseen, jääden suurinpiirtein muuntamattomana. Se tuli kuuluisuuteen 1960-luvulla kun Letraset-paperiarkit, joissa oli Lorem Ipsum pätkiä, julkaistiin ja vielä myöhemmin tietokoneen julkistusohjelmissa, kuten Aldus PageMaker joissa oli versioita Lorem Ipsumista.

Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.

Lorem Ipsum საბეჭდი და ტიპოგრაფიული ინდუსტრიის უშინაარსო ტექსტია. იგი სტანდარტად 1500-იანი წლებიდან იქცა, როდესაც უცნობმა მბეჭდავმა ამწყობ დაზგაზე წიგნის საცდელი ეგზემპლარი დაბეჭდა. მისი ტექსტი არამარტო 5 საუკუნის მანძილზე შემორჩა, არამედ მან დღემდე, ელექტრონული ტიპოგრაფიის დრომდეც უცვლელად მოაღწია. განსაკუთრებული პოპულარობა მას 1960-იან წლებში გამოსულმა Letraset-ის ცნობილმა ტრაფარეტებმა მოუტანა, უფრო მოგვიანებით კი — Aldus PageMaker-ის ტიპის საგამომცემლო პროგრამებმა, რომლებშიც Lorem Ipsum-ის სხვადასხვა ვერსიები იყო ჩაშენებული.

Lorem Ipsum ist ein einfacher Demo-Text für die Print- und Schriftindustrie. Lorem Ipsum ist in der Industrie bereits der Standard Demo-Text seit 1500, als ein unbekannter Schriftsteller eine Hand voll Wörter nahm und diese durcheinander warf um ein Musterbuch zu erstellen. Es hat nicht nur 5 Jahrhunderte überlebt, sondern auch in Spruch in die elektronische Schriftbearbeitung geschafft (bemerke, nahezu unverändert). Bekannt wurde es 1960, mit dem erscheinen von "Letraset", welches Passagen von Lorem Ipsum enhielt, so wie Desktop Software wie "Aldus PageMaker" - ebenfalls mit Lorem Ipsum.

Το Lorem Ipsum είναι απλά ένα κείμενο χωρίς νόημα για τους επαγγελματίες της τυπογραφίας και στοιχειοθεσίας. Το Lorem Ipsum είναι το επαγγελματικό πρότυπο όσον αφορά το κείμενο χωρίς νόημα, από τον 15ο αιώνα, όταν ένας ανώνυμος τυπογράφος πήρε ένα δοκίμιο και ανακάτεψε τις λέξεις για να δημιουργήσει ένα δείγμα βιβλίου. Όχι μόνο επιβίωσε πέντε αιώνες, αλλά κυριάρχησε στην ηλεκτρονική στοιχειοθεσία, παραμένοντας με κάθε τρόπο αναλλοίωτο. Έγινε δημοφιλές τη δεκαετία του \'60 με την έκδοση των δειγμάτων της Letraset όπου περιελάμβαναν αποσπάσματα του Lorem Ipsum, και πιο πρόσφατα με το λογισμικό ηλεκτρονικής σελιδοποίησης όπως το Aldus PageMaker που περιείχαν εκδοχές του Lorem Ipsum.

זוהי עובדה מבוססת שדעתו של הקורא תהיה מוסחת על ידי טקטס קריא כאשר הוא יביט בפריסתו. המטרה בשימוש ב-Lorem Ipsum הוא שיש לו פחות או יותר תפוצה של אותיות, בניגוד למלל \'� יסוי � יסוי � יסוי\', ונותן חזות קריאה יותר.הרבה הוצאות מחשבים ועורכי דפי אינטרנט משתמשים כיום ב-Lorem Ipsum כטקסט ברירת המחדל שלהם, וחיפוש של \'lorem ipsum\' יחשוף אתרים רבים בראשית דרכם.גרסאות רבות נוצרו במהלך השנים, לעתים בשגגה לעיתים במכוון (זריקת בדיחות וכדומה).

A Lorem Ipsum egy egyszerû szövegrészlete, szövegutánzata a betûszedõ és nyomdaiparnak. A Lorem Ipsum az 1500-as évek óta standard szövegrészletként szolgált az iparban; mikor egy ismeretlen nyomdász összeállította a betûkészletét és egy példa-könyvet vagy szöveget nyomott papírra, ezt használta. Nem csak 5 évszázadot élt túl, de az elektronikus betûkészleteknél is változatlanul megmaradt. Az 1960-as években népszerûsítették a Lorem Ipsum részleteket magukbafoglaló Letraset lapokkal, és legutóbb softwarekkel mint például az Aldus Pagemaker.

Lorem Ipsum adalah contoh teks atau dummy dalam industri percetakan dan penataan huruf atau typesetting. Lorem Ipsum telah menjadi standar contoh teks sejak tahun 1500an, saat seorang tukang cetak yang tidak dikenal mengambil sebuah kumpulan teks dan mengacaknya untuk menjadi sebuah buku contoh huruf. Ia tidak hanya bertahan selama 5 abad, tapi juga telah beralih ke penataan huruf elektronik, tanpa ada perubahan apapun. Ia mulai dipopulerkan pada tahun 1960 dengan diluncurkannya lembaran-lembaran Letraset yang menggunakan kalimat-kalimat dari Lorem Ipsum, dan seiring munculnya perangkat lunak Desktop Publishing seperti Aldus PageMaker juga memiliki versi Lorem Ipsum.

Lorem Ipsum è un testo segnaposto utilizzato nel settore della tipografia e della stampa. Lorem Ipsum è considerato il testo segnaposto standard sin dal sedicesimo secolo, quando un anonimo tipografo prese una cassetta di caratteri e li assemblò per preparare un testo campione. È sopravvissuto non solo a più di cinque secoli, ma anche al passaggio alla videoimpaginazione, pervenendoci sostanzialmente inalterato. Fu reso popolare, negli anni ’60, con la diffusione dei fogli di caratteri trasferibili “Letraset”, che contenevano passaggi del Lorem Ipsum, e più recentemente da software di impaginazione come Aldus PageMaker, che includeva versioni del Lorem Ipsum.

Lorem Ipsum – tas ir teksta salikums, kuru izmanto poligrāfijā un maketēšanas darbos. Lorem Ipsum ir kļuvis par vispārpieņemtu teksta aizvietotāju kopš 16. gadsimta sākuma. Tajā laikā kāds nezināms iespiedējs izveidoja teksta fragmentu, lai nodrukātu grāmatu ar burtu paraugiem. Tas ir ne tikai pārdzīvojis piecus gadsimtus, bet bez ievērojamām izmaiņām saglabājies arī mūsdienās, pārejot uz datorizētu teksta apstrādi. Tā popularizēšanai 60-tajos gados kalpoja Letraset burtu paraugu publicēšana ar Lorem Ipsum teksta fragmentiem un, nesenā pagātnē, tādas maketēšanas programmas kā Aldus PageMaker, kuras šablonu paraugos ir izmantots Lorem Ipsum teksts.

Lorem ipsum - tai fiktyvus tekstas naudojamas spaudos ir grafinio dizaino pasaulyje jau nuo XVI a. pradžios. Lorem Ipsum tapo standartiniu fiktyviu tekstu, kai nežinomas spaustuvininkas atsitiktine tvarka išdėliojo raides atspaudų prese ir tokiu būdu sukūrė raidžių egzempliorių. Šis tekstas išliko beveik nepasikeitęs ne tik penkis amžius, bet ir įžengė i kopiuterinio grafinio dizaino laikus. Jis išpopuliarėjo XX a. šeštajame dešimtmetyje, kai buvo išleisti Letraset lapai su Lorem Ipsum ištraukomis, o vėliau -leidybinė sistema AldusPageMaker, kurioje buvo ir Lorem Ipsum versija.

Lorem Ipsum е едноставен модел на текст кој се користел во печатарската индустрија. Lorem ipsum бил индустриски стандард кој се користел како модел уште пред 1500 години, кога непознат печатар зел кутија со букви и ги сложил на таков начин за да направи примерок на книга. И не само што овој модел опстанал пет векови туку почнал да се користи и во електронските медиуми, кој се уште не е променет. Се популаризирал во 60-тите години на дваесеттиот век со издавањето на збирка од страни во кои се наоѓале Lorem Ipsum пасуси, а денес во софтверскиот пакет како што е Aldus PageMaker во кој се наоѓа верзија на Lorem Ipsum.

Lorem Ipsum adalah text contoh digunakan didalam industri pencetakan dan typesetting. Lorem Ipsum telah menjadi text contoh semenjak tahun ke 1500an, apabila pencetak yang kurang terkenal mengambil sebuah galeri cetak dan merobakanya menjadi satu buku spesimen. Ia telah bertahan bukan hanya selama lima kurun, tetapi telah melonjak ke era typesetting elektronik, dengan tiada perubahan ketara. Ia telah dipopularkan pada tahun 1960an dengan penerbitan Letraset yang mebawa kangungan Lorem Ipsum, dan lebih terkini dengan sofwer pencetakan desktop seperti Aldus PageMaker yang telah menyertakan satu versi Lorem Ipsum.

Lorem Ipsum er rett og slett dummytekst fra og for trykkeindustrien. Lorem Ipsum har vært bransjens standard for dummytekst helt siden 1500-tallet, da en ukjent boktrykker stokket en mengde bokstaver for å lage et prøveeksemplar av en bok. Lorem Ipsum har tålt tidens tann usedvanlig godt, og har i tillegg til å bestå gjennom fem århundrer også tålt spranget over til elektronisk typografi uten vesentlige endringer. Lorem Ipsum ble gjort allment kjent i 1960-årene ved lanseringen av Letraset-ark med avsnitt fra Lorem Ipsum, og senere med sideombrekkingsprogrammet Aldus PageMaker som tok i bruk nettopp Lorem Ipsum for dummytekst.

Lorem Ipsum jest tekstem stosowanym jako przykładowy wypełniacz w przemyśle poligraficznym. Został po raz pierwszy użyty w XV w. przez nieznanego drukarza do wypełnienia tekstem próbnej książki. Pięć wieków później zaczął być używany przemyśle elektronicznym, pozostając praktycznie niezmienionym. Spopularyzował się w latach 60. XX w. wraz z publikacją arkuszy Letrasetu, zawierających fragmenty Lorem Ipsum, a ostatnio z zawierającym różne wersje Lorem Ipsum oprogramowaniem przeznaczonym do realizacji druków na komputerach osobistych, jak Aldus PageMaker

O Lorem Ipsum é um texto modelo da indústria tipográfica e de impressão. O Lorem Ipsum tem vindo a ser o texto padrão usado por estas indústrias desde o ano de 1500, quando uma misturou os caracteres de um texto para criar um espécime de livro. Este texto não só sobreviveu 5 séculos, mas também o salto para a tipografia electrónica, mantendo-se essencialmente inalterada. Foi popularizada nos anos 60 com a disponibilização das folhas de Letraset, que continham passagens com Lorem Ipsum, e mais recentemente com os programas de publicação como o Aldus PageMaker que incluem versões do Lorem Ipsum.

Lorem Ipsum este pur şi simplu o machetă pentru text a industriei tipografice. Lorem Ipsum a fost macheta standard a industriei încă din secolul al XVI-lea, când un tipograf anonim a luat o planşetă de litere şi le-a amestecat pentru a crea o carte demonstrativă pentru literele respective. Nu doar că a supravieţuit timp de cinci secole, dar şi a facut saltul în tipografia electronică practic neschimbată. A fost popularizată în anii \'60 odată cu ieşirea colilor Letraset care conţineau pasaje Lorem Ipsum, iar mai recent, prin programele de publicare pentru calculator, ca Aldus PageMaker care includeau versiuni de Lorem Ipsum.

Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века. В то время некий безымянный печатник создал большую коллекцию размеров и форм шрифтов, используя Lorem Ipsum для распечатки образцов. Lorem Ipsum не только успешно пережил без заметных изменений пять веков, но и перешагнул в электронный дизайн. Его популяризации в новое время послужили публикация листов Letraset с образцами Lorem Ipsum в 60-х годах и, в более недавнее время, программы электронной вёрстки типа Aldus PageMaker, в шаблонах которых используется Lorem Ipsum.

Lorem Ipsum је једноставно модел текста који се користи у штампарској и словослагачкој индустрији. Lorem ipsum је био стандард за модел текста још од 1500. године, када је непознати штампар узео кутију са словима и сложио их како би направио узорак књиге. Не само што је овај модел опстао пет векова, него је чак почео да се користи и у електронским медијима, непроменивши се. Популаризован је шездесетих година двадесетог века заједно са листовима летерсета који су садржали Lorem Ipsum пасусе, а данас са софтверским пакетом за прелом као што је Aldus PageMaker који је садржао Lorem Ipsum верзије.

Lorem Ipsum je fiktívny text, používaný pri návrhu tlačovín a typografie. Lorem Ipsum je štandardným výplňovým textom už od 16. storočia, keď neznámy tlačiar zobral sadzobnicu plnú tlačových znakov a pomiešal ich, aby tak vytvoril vzorkovú knihu. Prežil nielen päť storočí, ale aj skok do elektronickej sadzby, a pritom zostal v podstate nezmenený. Spopularizovaný bol v 60-tych rokoch 20.storočia, vydaním hárkov Letraset, ktoré obsahovali pasáže Lorem Ipsum, a neskôr aj publikačným softvérom ako Aldus PageMaker, ktorý obsahoval verzie Lorem Ipsum.

Lorem Ipsum je slepi tekst, ki se uporablja pri razvoju tipografij in pri pripravi za tisk. Lorem Ipsum je v uporabi že več kot petsto let saj je to kombinacijo znakov neznani tiskar združil v vzorčno knjigo že v začetku 16. stoletja. To besedilo pa ni zgolj preživelo pet stoletij, temveč se je z malenkostnimi spremembami uspešno uveljavilo tudi v elektronskem namiznem založništvu. Na priljubljenosti je Lorem Ipsum pridobil v sedemdesetih letih prejšnjega stoletja, ko so na trg lansirali Letraset folije z Lorem Ipsum odstavki. V zadnjem času se Lorem Ipsum pojavlja tudi v priljubljenih programih za namizno založništvo kot je na primer Aldus PageMaker.

Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creación de las hojas "Letraset", las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.

Lorem Ipsum är en utfyllnadstext från tryck- och förlagsindustrin. Lorem ipsum har varit standard ända sedan 1500-talet, när en okänd boksättare tog att antal bokstäver och blandade dem för att göra ett provexemplar av en bok. Lorem ipsum har inte bara överlevt fem århundraden, utan även övergången till elektronisk typografi utan större förändringar. Det blev allmänt känt på 1960-talet i samband med lanseringen av Letraset-ark med avsnitt av Lorem Ipsum, och senare med mjukvaror som Aldus PageMaker.

Lorem Ipsum คือ เนื้อหาจำลองแบบเรียบๆ ที่ใช้กันในธุรกิจงานพิมพ์หรืองานเรียงพิมพ์ มันได้กลายมาเป็นเนื้อหาจำลองมาตรฐานของธุรกิจดังกล่าวมาตั้งแต่ศตวรรษที่ 16 เมื่อเครื่องพิมพ์โนเนมเครื่องหนึ่งนำรางตัวพิมพ์มาสลับสับตำแหน่งตัวอักษรเพื่อทำหนังสือตัวอย่าง Lorem Ipsum อยู่ยงคงกระพันมาไม่ใช่แค่เพียงห้าศตวรรษ แต่อยู่มาจนถึงยุคที่พลิกโฉมเข้าสู่งานเรียงพิมพ์ด้วยวิธีทางอิเล็กทรอนิกส์ และยังคงสภาพเดิมไว้อย่างไม่มีการเปลี่ยนแปลง มันได้รับความนิยมมากขึ้นในยุค ค.ศ. 1960 เมื่อแผ่น Letraset วางจำหน่ายโดยมีข้อความบนนั้นเป็น Lorem Ipsum และล่าสุดกว่านั้น คือเมื่อซอฟท์แวร์การทำสื่อสิ่งพิมพ์ (Desktop Publishing) อย่าง Aldus PageMaker ได้รวมเอา Lorem Ipsum เวอร์ชั่นต่างๆ เข้าไว้ในซอฟท์แวร์ด้วย

Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960\'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.

Lorem Ipsum - це текст-"риба", що використовується в друкарстві та дизайні. Lorem Ipsum є, фактично, стандартною "рибою" аж з XVI сторіччя, коли невідомий друкар взяв шрифтову гранку та склав на ній підбірку зразків шрифтів. "Риба" не тільки успішно пережила п\'ять століть, але й прижилася в електронному верстуванні, залишаючись по суті незмінною. Вона популяризувалась в 60-их роках минулого сторіччя завдяки виданню зразків шрифтів Letraset, які містили уривки з Lorem Ipsum, і вдруге - нещодавно завдяки програмам комп\'ютерного верстування на кшталт Aldus Pagemaker, які використовували різні версії Lorem Ipsum.

';


$gbStringPatternTestAll = $gbStringPatternTest.' '.$gbLipsumPatternTest;








$gbPublicConfigsData = false;

$gbLevel = $xtraffic_Configs['test_level'];

if(isset($_GET['test_level']) && $_GET['test_level']) {
	$_GET['test_level'] = (int)$_GET['test_level'];
	if($_GET['test_level']>1) {
		$gbLevel = $_GET['test_level'];
	}
}

$gbLevel = abs((int)$gbLevel);
if($gbLevel<1) {
	$gbLevel = 1;
}


function bm_microtime_float()
{
    $r = number_format(microtime(true), 8, '.', '');
	
	$r = (float)$r;
	
	return $r;
	
}



function xtraffic_MergeArrays($input_parameters)
{
	$merged = false;
	
	if(is_array($input_parameters)) {
	
		$merged = array_shift($input_parameters); // using 1st array as base
		
		foreach($input_parameters as $array) {
			foreach ($array as $key => $value) {
				
				if(isset($merged[$key]) && is_array($value) && is_array($merged[$key])) {
					$merged[$key] = xtraffic_MergeArrays(array($merged[$key], $value));
					
				} else {
					if(preg_match('/^[0-9]+$/i', $key)) {
						$merged[] = $value;
					} else {
						$merged[$key] = $value;
					}
				}
			}
		}
	}
	
	return $merged;
}//End Function


function xtraffic_ToNumber($input_text)
{
	$input_text = trim($input_text);
	if($input_text) {
		if(!is_numeric($input_text)) {
			$input_text = preg_replace('/[^0-9\.\+\-]+/', '', $input_text);
		}
	}
	
	$input_text = (float)$input_text;
	
	return $input_text;
}


function xtraffic_ReduceSpace($input_text)
{
	
	if($input_text) {
		$input_text = preg_replace('#[\t ]+#is',' ',$input_text);
		$input_text = preg_replace('#(\s)+#is','\1',$input_text);
	}
	
	$input_text = trim($input_text);
	
	return $input_text;
}

function xtraffic_RandomHash()
{
	$resultData = mt_rand().'_'.microtime(true).'_'.mt_rand();
	$resultData = md5($resultData);
	return $resultData;
}


function xtraffic_ProcessFileSizeString($input_file_size) //in KB
{
	//$totalFileSize = xtraffic_ToNumber($input_file_size);
    $totalFileSize = (float)$input_file_size;
	$totalFileSizeString = '';
	
	if(($totalFileSize>0) && ($totalFileSize<1024)) {
        $totalFileSize = round($totalFileSize,2);
		$totalFileSizeString = $totalFileSize.' KB';
	} else {
		$totalFileSize = round($totalFileSize/1024,2);
		if(($totalFileSize>=1) && ($totalFileSize<1024)) {
			$totalFileSizeString = $totalFileSize.' MB';
		} else {
			$totalFileSize = round($totalFileSize/1024,2);
			if(($totalFileSize>=1) && ($totalFileSize<1024)) {
				$totalFileSizeString = $totalFileSize.' GB';
			} else {
				$totalFileSize = round($totalFileSize/1024,2);
				if(($totalFileSize>=1) && ($totalFileSize<1024)) {
					$totalFileSizeString = $totalFileSize.' TB';
				}
			}
		}
	}
	
	return $totalFileSizeString;
}


function xtraffic_StripTheHTTPHeaders($response) 
{
	$pos = strpos($response, "\r\n\r\n");
	
	if(false !== $pos) {
		$response = substr($response, $pos + 4);
	}
	
	return $response;
}


function xtraffic_GetRemoteFileViaCurl($url, $args = array())
{
	global $gbPublicConfigsData;
	
	$resultData = array(
		'body' => ''
		,'size' => 0
		,'speed' => 0
		,'speed_string' => '0 Byte/s'
		,'total_time' => 0
		,'receive_time' => 0
	);
	
	$connect_timeout = abs((int)$args['timeout']);
	
	$opts_UserAgent = 'PHP_CURL';
	
	if($gbPublicConfigsData && isset($gbPublicConfigsData['test_network']['http-user-agent']) && $gbPublicConfigsData['test_network']['http-user-agent']) {
		$opts_UserAgent = $gbPublicConfigsData['test_network']['http-user-agent'];
	}
	
	$opts_Headers = array();
	$opts_Headers['user-agent'] = 'User-Agent: '.$opts_UserAgent;
	$opts_Headers['accept'] = 'Accept: */*;';
	$opts_Headers['accept-encoding'] = 'Accept-Encoding: gzip,deflate';
	$opts_Headers['accept-charset'] = 'Accept-Charset: UTF-8,*;';
	$opts_Headers['keep-alive'] = 'Keep-Alive: 300';
	$opts_Headers['connection'] = 'Connection: keep-alive';
	
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, $opts_UserAgent);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $opts_Headers);
	curl_setopt($ch, CURLOPT_ENCODING, 'utf-8');
	curl_setopt($ch, CURLOPT_TIMEOUT, $connect_timeout);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	
	$filePathDownload = './curl_file_get_temp_'.xtraffic_RandomHash().'.txt';
	$fohd = @fopen($filePathDownload,'w+');
	if($fohd) {
		curl_setopt($ch, CURLOPT_FILE, $fohd); // write curl response to file
	}
	
	$time_start1 = microtime(true);
    $time_start1 = (float)$time_start1;
	if(isset($args['test_speed_only_status']) && $args['test_speed_only_status']) {
		curl_exec($ch);
	} else {
		$resultData['body'] = curl_exec($ch);
	}
	$resultData['receive_time'] = number_format(abs(microtime(true) - $time_start1), 8, '.', ''); 
	
	$chInfo = curl_getinfo($ch);
	
	curl_close($ch);$ch=NULL;unset($ch);$ch = '';
	if($fohd) {
		fclose($fohd);
	}
	$fohd=NULL;unset($fohd);$fohd = '';
	if(file_exists($filePathDownload)) {
		@unlink($filePathDownload);
	}
	
	if($chInfo) {
		if(isset($chInfo['speed_download']) && $chInfo['speed_download']) {
			$resultData['speed'] = $chInfo['speed_download'];
		}
		
		if(isset($chInfo['size_download']) && $chInfo['size_download']) {
			$resultData['size'] = $chInfo['size_download'];
		}
		
		if(isset($chInfo['total_time']) && $chInfo['total_time']) {
			$resultData['total_time'] = $chInfo['total_time'];
		}
		
		if(!isset($chInfo['namelookup_time'])) {
			$chInfo['namelookup_time'] = 0;
		}
		
		if(!isset($chInfo['connect_time'])) {
			$chInfo['connect_time'] = 0;
		}
		
		
		if(!isset($chInfo['pretransfer_time'])) {
			$chInfo['pretransfer_time'] = 0;
		}
		
		$resultData['receive_time'] = abs($resultData['total_time'] - ($chInfo['namelookup_time'] + $chInfo['connect_time'] + $chInfo['pretransfer_time']));
		
	}
	
	
	if($resultData['receive_time']>0) {
		$resultData['speed'] = $resultData['size'] / ((float)$resultData['receive_time']);
		$resultData['speed'] = (float)$resultData['speed'];
	}
	
	if($resultData['speed']>0) {
		$resultData['speed_string'] = xtraffic_ProcessFileSizeString(ceil($resultData['speed']/1024)).'/s';
	}
	
	
	return $resultData;
}

function xtraffic_GetRemoteFile($url, $args = array())
{
	global $gbPublicConfigsData;
	
	$resultData = array(
		'body' => ''
		,'size' => 0
		,'speed' => 0
		,'speed_string' => '0 Byte/s'
		,'total_time' => 0
		,'receive_time' => 0
	);
	
	
	

	$defaults = array(
		'method' => 'GET', 'timeout' => 3,
		'buffer_size' => 8192,
		'redirection' => 5, 'httpversion' => '1.0',
		'blocking' => true,
		'headers' => array(), 'body' => null, 'cookies' => array()
	);
	
	$args = xtraffic_MergeArrays(array(
		$defaults
		,$args
	));
	
	
	if(isset($args['via_curl']) && $args['via_curl']) {  
		if(function_exists('curl_init')) {
			return xtraffic_GetRemoteFileViaCurl($url, $args);
		}
	}
	
	
	
	
	
	
	
	
	
	$connect_timeout = abs((int)$args['timeout']);
	
	// get the host name and url path
	$parsedUrl = parse_url($url);
	$host = $parsedUrl['host'];
	if (isset($parsedUrl['path'])) {
		$path = $parsedUrl['path'];
	} else {
		
		$path = '/';
	}

	if (isset($parsedUrl['query'])) {
		$path .= '?' . $parsedUrl['query'];
	} 

	if (isset($parsedUrl['port'])) {
		$port = $parsedUrl['port'];
	} else {
		// most sites use port 80
		$port = '80';
	}

	$timeout = (int)$args['timeout'];
	$bufferSize = (int)$args['buffer_size'];
	$bufferSize = abs($bufferSize);
	$bufferSize = (int)$bufferSize;
	
	$opts_UserAgent = 'PHP_SOCKET';
	
	if($gbPublicConfigsData && isset($gbPublicConfigsData['test_network']['http-user-agent']) && $gbPublicConfigsData['test_network']['http-user-agent']) {
		$opts_UserAgent = $gbPublicConfigsData['test_network']['http-user-agent'];
	}
	
	$time_start = microtime(true);
	
	// connect to the remote server 
	$remote_handle = @fsockopen($host, '80', $errno, $errstr, $connect_timeout );

	if( !$remote_handle ) { 
		//echo "Cannot retrieve $url";
		return $resultData;
	} else {
		// send the necessary headers to get the file //fputs,fwrite
		fwrite($remote_handle, "GET $path HTTP/1.0\r\n" .
			"Host: $host\r\n" .
			"User-Agent: $opts_UserAgent\r\n" .
			"Accept: */*\r\n" .
			"Accept-Language: en-us,en;q=0.5\r\n" .
			"Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7\r\n" .
			//"Accept-Encoding: gzip, deflate, compress;q=0.9\r\n" . //don't use gzip
			"Keep-Alive: 300\r\n" .
			"Connection: keep-alive\r\n" .
			"Cache-Control: max-age=0\r\n" . 
			"Referer: http://$host\r\n\r\n"
		);
		
		if(isset($args['filename']) && $args['filename']) {
			if ( ! XTRAFFIC_DEBUG ) {
				$file_handle = @fopen( $args['filename'], 'w+' );
			} else {
				$file_handle = fopen( $args['filename'], 'w+' );
			}
			
			if (!$file_handle ) {
				return $resultData;
			} else {
				
				$isStripTheHTTPHeadersStatus = false;
				
				$time_start1 = microtime(true);
                
                $time_start1 = (float)$time_start1;
				
				while ( $line = fread( $remote_handle, $bufferSize ) ) {
					
					$resultData['size'] += strlen($line);
					
					if(!$isStripTheHTTPHeadersStatus) {
						$isStripTheHTTPHeadersStatus = true;
						$line = xtraffic_StripTheHTTPHeaders($line);
					}
					
					
					$bytes_written_to_file = fwrite( $file_handle, $line );
					
					
				}
				
				$resultData['receive_time'] = number_format(abs(microtime(true) - $time_start1), 8, '.', '');
				
				fclose( $file_handle );
			}
			
		} else if(isset($args['test_speed_only_status']) && $args['test_speed_only_status']) {
			
			$time_start1 = microtime(true);
			$time_start1 = (float)$time_start1;
			while ( $line = fread( $remote_handle, $bufferSize ) ) {
				$resultData['size'] += strlen($line);
			}
			
			$resultData['receive_time'] = number_format(abs(microtime(true) - $time_start1), 8, '.', ''); 
			
		} else {
			
			$time_start1 = microtime(true);
			$time_start1 = (float)$time_start1;
			// retrieve the response from the remote server 
			while ( $line = fread( $remote_handle, $bufferSize ) ) { 
				$resultData['size'] += strlen($line);
				$resultData['body'] .= $line;
			}
			
			$resultData['receive_time'] = number_format(abs(microtime(true) - $time_start1), 8, '.', '');
			
			$resultData['body'] = xtraffic_StripTheHTTPHeaders($resultData['body']);
		}
		
		fclose( $remote_handle );
		
		
	}

	$resultData['total_time'] = number_format(microtime(true) - $time_start, 8, '.', '');
	
	if($resultData['receive_time']>0) {
		
		$resultData['speed'] = $resultData['size'] / ((float)$resultData['receive_time']);
		$resultData['speed'] = (float)$resultData['speed'];
		
		$resultData['speed_string'] = xtraffic_ProcessFileSizeString(ceil($resultData['speed']/1024)).'/s';
	}
	
	// return the file content 
	return $resultData;
	
}








function xtraffic_TestCPU_Math($count = 10000) 
{

	global $gbLevel;
	$count = $count * $gbLevel;
	
	$time_start = microtime(true);
	
	$mathFunctions = array(
		'abs'
		,'acos'
		,'asin'
		,'atan'
		,'bindec'
		,'floor'
		,'exp'
		,'sin'
		,'tan'
		,'pi'
		,'is_finite'
		,'is_nan'
		,'sqrt'
		,'acosh'
		,'asinh'
		,'ceil'
		,'cosh'
		,'decbin'
		,'dechex'
		,'decoct'
		,'deg2rad'
		,'expm1'
		,'log10'
		,'log1p'
		,'log'
		,'rad2deg'
		,'round'
		,'sinh'
		,'tanh'
	);
	
	$isFullFunctionsStatus = true;
	foreach ($mathFunctions as $key => $function) {
		if (!function_exists($function)) {
			echo 'Your Host/PHP version not support function "'.$function.'". This lib require PHP version >= 5.2';
			$isFullFunctionsStatus = false;
		}
	}
	if(!$isFullFunctionsStatus) {
		exit();
	}
	
	for ($i=0; $i < $count; $i++) {
		foreach ($mathFunctions as $function) {
			$r = call_user_func_array($function, array($i));
		}
	}
	
	return number_format(microtime(true) - $time_start, 8, '.', '');
}


function xtraffic_TestCPU_StringManipulation($count = 80) 
{
	global $gbLevel;
	$count = $count * $gbLevel;
	
	$time_start = microtime(true);
	$stringFunctions = array(
		'addslashes'
		,'chunk_split'
		,'count_chars'
		,'crc32'
		,'crypt'
		,'html_entity_decode'
		,'htmlentities'
		,'htmlspecialchars_decode'
		,'htmlspecialchars'
		,'lcfirst'
		,'nl2br'
		,'rtrim'
		,'quotemeta'
		,'quoted_printable_decode'
		,'quoted_printable_encode'
		,'soundex'
		,'str_rot13'
		,'str_shuffle'
		,'str_split'
		,'str_word_count'
		,'stripcslashes'
		,'stripslashes'
		,'strtolower'
		,'strtoupper'
		,'trim'
		,'ucfirst'
		,'ucwords'
		,'metaphone'
		,'strip_tags'
		,'md5'
		,'sha1'
		,'strrev'
		,'strlen'
		,'ord'
	);
	
	$isFullFunctionsStatus = true;
	foreach ($stringFunctions as $key => $function) {
		if (!function_exists($function)) {
			echo 'Your Host/PHP version not support function "'.$function.'". This lib require PHP version >= 5.2';
			$isFullFunctionsStatus = false;
		}
	}
	if(!$isFullFunctionsStatus) {
		exit();
	}
	
	global $gbStringPatternTest;
	$string = $gbStringPatternTest;
	for ($i=0; $i < $count; $i++) {
		foreach ($stringFunctions as $function) {
			if('crypt' === $function) {
				$r = call_user_func_array($function, array($string,''));
			} else {
				$r = call_user_func_array($function, array($string));
			}
		}
	}
	
	return number_format(microtime(true) - $time_start, 8, '.', '');
	
}


function xtraffic_TestCPU_HashString($count = 200) 
{
	global $gbLevel;
	$count = $count * $gbLevel;
	
	$time_start = microtime(true);
	$stringFunctions = hash_algos();
	$stringFunctions = (array)$stringFunctions;
	
	global $gbStringPatternTest;
	$string = $gbStringPatternTest;
	
	for ($i=0; $i < $count; $i++) {
		foreach ($stringFunctions as $function) {
			$r = hash($function, $string);
		}
	}
	
	return number_format(microtime(true) - $time_start, 8, '.', '');
}


function xtraffic_TestCPU_GzipString($count = 20) 
{
	global $gbLevel;
	$count = $count * $gbLevel;
	
	$time_start = microtime(true);
	
	global $gbStringPatternTestAll;
	$string = $gbStringPatternTestAll;
	
	for ($i=0; $i < $count; $i++) {
		for ($x=1; $x < 10; $x++) {
			$r = gzcompress($string,$x);
			$r = gzuncompress($r);
			
		}
	}
	
	return number_format(microtime(true) - $time_start, 8, '.', '');
}




function xtraffic_TestCPU_Loops($count = 2000000) 
{
	global $gbLevel;
	$count = $count * $gbLevel;
	
	$time_start = microtime(true);
	for($i = 0; $i < $count; $i++) {
		
	}
	
	$i = 0;
	while($i < $count) {
		$i++;
	}
	
	return number_format(microtime(true) - $time_start, 8, '.', '');
	
}


function xtraffic_TestCPU_IfElse($count = 1000000) 
{
	global $gbLevel;
	$count = $count * $gbLevel;
	
	$time_start = microtime(true);
	for ($i=0; $i < $count; $i++) {
		if ($i == -1) {
		} elseif ($i == -2) {
		} else if ($i == -3) {
		} else if ($i === -4) {
		} else if ($i < -1) {
		} else if ($i <= -1) {
		}
	}
	
	return number_format(microtime(true) - $time_start, 8, '.', '');
	
}	


function xtraffic_TestCPU_Synthetic($count = 100) 
{
	global $gbLevel;
	$count = $count * $gbLevel;
	
	$time_start = microtime(true);
	
	global $gbStringPatternTestAll;
	$string = $gbStringPatternTestAll;
	
	$targetArray = array();
	$targetArray['a'] = array();
	$targetArray['b'] = array();
	$targetArray['c'] = array();
	$targetArray['a']['a'] = array();
	$targetArray['a']['b'] = array();
	$targetArray['a']['c'] = array();
	$targetArray['t'] = $string;
	$targetArray['n'] = array();
	
	for($i = 0; $i < ($count * 10); $i++) {
		$targetArray['n'][] = $i;
	}
	
	for ($i=0; $i < $count; $i++) {
		$r = json_encode($targetArray);
		$r = json_decode($r);
		
		$r = serialize($targetArray);
		$r = unserialize($r);
	}
	
	return number_format(microtime(true) - $time_start, 8, '.', '');
	
}







function xtraffic_TestDataStorageDevice_TestWrite() 
{
	global $gbLevel;
	
	$resultData = array(
		
	);
	
	$fileName = xtraffic_RandomHash().'.txt';
	$filePath = './'.$fileName;
	
	$dataWrite_128B = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789abcdef';
	
	$bufferSize = (1024 * 1024) * 1 * $gbLevel;//x MB
	
	$round1 = $bufferSize / strlen($dataWrite_128B);
	$round1 = ceil($round1);
	
	$dataWrite_Buffer = '';
	
	for($i=0;$i<$round1;$i++) {
		$dataWrite_Buffer .= $dataWrite_128B;
	}
	
	$dataWrite_BufferLength = strlen($dataWrite_Buffer);
	$dataWrite_BufferLength = (float)$dataWrite_BufferLength;
	
	$dataNeedWriteLength = (1024 * 1024) * 20 * $gbLevel;//x MB
	
	$numberRoundTest = 5 * $gbLevel;
	$totalTestSpeed = 0;
	$totalTimeSpend = 0;
	$totalDataProcessed = 0;
	$totalDataProcessed = (float)$totalDataProcessed;
	
	for($i=0;$i<$numberRoundTest;$i++) {
		clearstatcache();
		if(is_file($filePath)) {
			unlink($filePath);
		}
		clearstatcache();
		
		$dataWroteLength1 = 0;
		$dataWroteLength1 = (float)$dataWroteLength1;
		
		$time_start1 = microtime(true);
		
		$fohd = @fopen($filePath,'w+');
		if($fohd) {
			
			while($dataWroteLength1 < $dataNeedWriteLength) {
				if(fwrite($fohd,$dataWrite_Buffer)) {
					$dataWroteLength1 += $dataWrite_BufferLength;
				}
			}
			
			
			fclose($fohd);$fohd=NULL;unset($fohd);$fohd=0;
		}
		
		$time_spend1 = microtime(true) - $time_start1;
		
		$totalDataProcessed += ($dataWroteLength1 / 1024);
		
		$totalTestSpeed += $dataWroteLength1/$time_spend1;
		$totalTimeSpend += $time_spend1;
	}
	
	
	$resultData['time_spend'] = $totalTimeSpend / $numberRoundTest;
	$resultData['file_path'] = $filePath;
	$resultData['file_size'] = $dataNeedWriteLength;
	$resultData['file_size_string'] = xtraffic_ProcessFileSizeString(ceil($resultData['file_size'] / 1024));
	$resultData['write_speed'] = $totalDataProcessed / $totalTimeSpend;
	$resultData['write_speed_string'] = xtraffic_ProcessFileSizeString(ceil($resultData['write_speed'])).'/s';
	$resultData['buffer_length'] = $dataWrite_BufferLength;
	$resultData['number_round_test'] = $numberRoundTest;
	
	
	return $resultData;
}




function xtraffic_TestDataStorageDevice_TestRead($input_parameters) 
{
	global $gbLevel;
	
	$resultData = array(
		
	);
	
	
	$filePath = $input_parameters['file_path'];
	if(is_file($filePath) && is_readable($filePath)) {
		$bufferLength = $input_parameters['buffer_length'];
		$bufferLength = (int)$bufferLength;
		
		$fileSize = filesize($filePath);
		$fileSize = (float)$fileSize;
		
		if($fileSize>0) {
			
			$numberRoundTest = $input_parameters['number_round_test'];
			$numberRoundTest = (int)$numberRoundTest;
			
			$totalTestSpeed = 0;
			$totalTimeSpend = 0;
			$totalDataProcessed = 0;
			$totalDataProcessed = (float)$totalDataProcessed;
			
			for($i=0;$i<$numberRoundTest;$i++) {
				
				$dataReadLength1 = 0;
				$dataReadLength1 = (float)$dataReadLength1;
				
				$time_start1 = microtime(true);
				
				$fohd = @fopen($filePath,'rb');
				if($fohd) {
					
					$fcontent = '';
					
					while (!feof($fohd)) {
						if(false !== ($fcontent = fread($fohd, $bufferLength))) {
							$dataReadLength1 += $bufferLength;
						}
					}
					
					fclose($fohd);$fohd=NULL;unset($fohd);$fohd=0; 
				}
				
				$time_spend1 = microtime(true) - $time_start1;
				
				$totalDataProcessed += ($dataReadLength1 / 1024); 
				
				$totalTestSpeed += $fileSize/$time_spend1;
				$totalTimeSpend += $time_spend1;
			}
			
			
			
			$resultData['time_spend'] = $totalTimeSpend / $numberRoundTest;
			$resultData['file_path'] = $filePath;
			$resultData['file_size'] = $fileSize;
			$resultData['file_size_string'] = xtraffic_ProcessFileSizeString(ceil($resultData['file_size'] / 1024));
			$resultData['read_speed'] = $totalDataProcessed / $totalTimeSpend;
			$resultData['read_speed_string'] = xtraffic_ProcessFileSizeString(ceil($resultData['read_speed'])).'/s';
			$resultData['buffer_length'] = $bufferLength;
						
		}
	
	
	
	}


	if(file_exists($filePath)) {
		unlink($filePath);
	}
	
	return $resultData;
}







function xtraffic_TestDataStorageDevice() 
{
	global $xtraffic_Configs;
	global $strPadNum1;
	global $strAllPadNum;
	
	
	$resultData = '';
	
	if($xtraffic_Configs['test_data_storage_device']) {
		$rsTestWrite = xtraffic_TestDataStorageDevice_TestWrite();
		$rsTestRead = xtraffic_TestDataStorageDevice_TestRead($rsTestWrite);
		if(count($rsTestRead)>0) {
			
			$rsStr1  = str_pad('+ TEST WRITE     : ', $strPadNum1).PHP_EOL;
			$rsStr1 .= str_pad('      File Size  : '.$rsTestWrite['file_size_string'].'', $strPadNum1).PHP_EOL;
			$rsStr1 .= str_pad('      Time       : '.$rsTestWrite['time_spend'].' seconds', $strPadNum1).PHP_EOL;
			$rsStr1 .= str_pad('      Speed      : '.$rsTestWrite['write_speed_string'].'', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			
			
			$rsStr1  = str_pad('+ TEST READ     : ', $strPadNum1).PHP_EOL;
			$rsStr1 .= str_pad('      File Size  : '.$rsTestRead['file_size_string'].'', $strPadNum1).PHP_EOL;
			$rsStr1 .= str_pad('      Time       : '.$rsTestRead['time_spend'].' seconds', $strPadNum1).PHP_EOL;
			$rsStr1 .= str_pad('      Speed      : '.$rsTestRead['read_speed_string'].'', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			
			$rsStr1 = str_pad('-', ceil($strAllPadNum/4) , '-') . PHP_EOL . '* '.str_pad('Total time ', $strPadNum1) . ' : ' . number_format(($rsTestWrite['time_spend'] + $rsTestRead['time_spend']), 8, '.', ',') . ' seconds.'.PHP_EOL;
			$resultData .= $rsStr1;

			
		} else {
			
			$rsStr1 = str_pad('+ ERROR!!! : CAN NOT "READ/WRITE" FOLDER "'.realpath('./').'". PLEASE CHMOD 0777 THIS FOLDER TO TEST DATA STORAGE DEVICE (HDD/SSD)', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			
			
		}
	}
	
	return $resultData;
}












function xtraffic_ParsePublicConfigs() 
{
	$publicConfigsData = file_get_contents('http://static.pep.vn/library/pepvn/host-vps-server/benchmark/php-benchmark-script-by-xtraffic-pep-vn-public-configs.json');
	
	if($publicConfigsData) {
		$publicConfigsData = trim($publicConfigsData);
		if($publicConfigsData) {
			$publicConfigsData = json_decode($publicConfigsData,true,9999);
		}
	}
	
	if(isset($publicConfigsData['version']) && $publicConfigsData['version']) {
		global $gbPublicConfigsData;
		$gbPublicConfigsData = $publicConfigsData;
	}
}

xtraffic_ParsePublicConfigs();


function xtraffic_TestNetwork() 
{

	global $gbPublicConfigsData;
	global $xtraffic_Configs;
	global $strPadNum1;
	
	$resultData = '';
	
	if(isset($xtraffic_Configs['test_network']['target']) && $xtraffic_Configs['test_network']['target']) {
		if(!isset($xtraffic_Configs['test_network']['max_number_download'])) {
			$xtraffic_Configs['test_network']['max_number_download'] = 0;
		}
		$xtraffic_Configs['test_network']['max_number_download'] = abs((int)$xtraffic_Configs['test_network']['max_number_download']);
		
		if($gbPublicConfigsData && isset($gbPublicConfigsData['version']) && $gbPublicConfigsData['version']) {
			$time_start = microtime(true);
			
			if(
				isset($gbPublicConfigsData['test_network']['target_test_speed_urls'])
				&& ($gbPublicConfigsData['test_network']['target_test_speed_urls'])
				&& is_array($gbPublicConfigsData['test_network']['target_test_speed_urls'])
				&& (count($gbPublicConfigsData['test_network']['target_test_speed_urls'])>0)
			) {
				$target_test_speed_urls = array();
				if(
					('main' === $xtraffic_Configs['test_network']['target']) 
					|| ('all' === $xtraffic_Configs['test_network']['target'])
				) {
					if(
						isset($gbPublicConfigsData['test_network']['target_test_speed_urls']['main'])
						&& is_array($gbPublicConfigsData['test_network']['target_test_speed_urls']['main'])
						&& (count($gbPublicConfigsData['test_network']['target_test_speed_urls']['main'])>0)
					) {
						$target_test_speed_urls = array_merge($target_test_speed_urls, $gbPublicConfigsData['test_network']['target_test_speed_urls']['main']);
					}
				}
				
				if(
					('all' === $xtraffic_Configs['test_network']['target']) 
				) {
					if(
						isset($gbPublicConfigsData['test_network']['target_test_speed_urls']['others'])
						&& is_array($gbPublicConfigsData['test_network']['target_test_speed_urls']['others'])
						&& (count($gbPublicConfigsData['test_network']['target_test_speed_urls']['others'])>0)
					) {
						$target_test_speed_urls = array_merge($target_test_speed_urls, $gbPublicConfigsData['test_network']['target_test_speed_urls']['others']);
					}
				}
				
				
				$iNumberDownloaded = 0;
				foreach($target_test_speed_urls as $valueOne) {
					if($valueOne) {
						if(isset($valueOne['url'])) {
							if($valueOne['url']) {
								$parsedUrl1 = parse_url($valueOne['url']);
								$host1 = $parsedUrl1['host'];
								$rsOne = xtraffic_GetRemoteFile($valueOne['url'],array(
									'via_curl' => true,
									'test_speed_only_status' => true
								));
								
								$rsStr1 = str_pad('+ Test download speed from "'.$host1.'"', $strPadNum1).PHP_EOL;
								
								if(isset($valueOne['location'])) {
									
									$rsStr1 .= str_pad('      [Location : '.$valueOne['location'].']', $strPadNum1).PHP_EOL;
								}
								
								
								$rsStr1 .= str_pad('      Size : '.xtraffic_ProcessFileSizeString(ceil($rsOne['size']/1024)).'', $strPadNum1).PHP_EOL;
								
								$rsStr1 .= str_pad('      Download Time : '.$rsOne['receive_time'].' sec', $strPadNum1).PHP_EOL;
								
								$rsStr1 .= str_pad('      Speed : '.$rsOne['speed_string'].'', $strPadNum1) . PHP_EOL . PHP_EOL;
								
								$resultData .= $rsStr1;
								
								$iNumberDownloaded++;
								
								if($xtraffic_Configs['test_network']['max_number_download']>0) {
									if($iNumberDownloaded >= $xtraffic_Configs['test_network']['max_number_download']) {
										break;
									}
								}
							}
						}
					}
					
				}
				
			}
			
		}
	}
	
	return $resultData;
}



$xtraffic_TestMySQL_PDOConnection = false;
$xtraffic_TestMySQL_MySQL_I_Connection = false;
$xtraffic_TestMySQL_MySQL_Connection = false;



function xtraffic_TestMySQL_DbQuery($input_query_string) 
{
	global $xtraffic_TestMySQL_PDOConnection;
	global $xtraffic_TestMySQL_MySQL_I_Connection;
	global $xtraffic_TestMySQL_MySQL_Connection;
	
	$resultData = false;
	
	if($xtraffic_TestMySQL_PDOConnection) {
		
		$sth = $xtraffic_TestMySQL_PDOConnection->prepare($input_query_string);
		if($sth) {
			if($sth->execute()) {
				$resultData = $sth;
			}
		}
	} else if($xtraffic_TestMySQL_MySQL_I_Connection) {
		$resultData = mysqli_query($xtraffic_TestMySQL_MySQL_I_Connection, $input_query_string, MYSQLI_STORE_RESULT);
	} else if($xtraffic_TestMySQL_MySQL_Connection) {
		$resultData = mysql_query($input_query_string,$xtraffic_TestMySQL_MySQL_Connection);
	}
	
	return $resultData;
}




function xtraffic_TestMySQL_DbParseResult($input_result) 
{
	global $xtraffic_TestMySQL_PDOConnection;
	global $xtraffic_TestMySQL_MySQL_I_Connection;
	global $xtraffic_TestMySQL_MySQL_Connection;
	
	$resultData = false;
	
	if($input_result) {
		if($xtraffic_TestMySQL_PDOConnection) {
			
			while($row = $input_result->fetch(PDO::FETCH_ASSOC)) {
				if($row) {
					$resultData[] = $row;
				}
			}
		} else if($xtraffic_TestMySQL_MySQL_I_Connection) {
			while($row = mysqli_fetch_assoc($input_result)) {
				if($row) {
					$resultData[] = $row;
				}
			}
		} else if($xtraffic_TestMySQL_MySQL_Connection) {
			while($row = mysql_fetch_assoc($input_result)) {
				if($row) {
					$resultData[] = $row;
				}
			}
		}
	}
	
	return $resultData;
}



function xtraffic_TestMySQL_CloseDbConnection() 
{
	global $xtraffic_TestMySQL_PDOConnection;
	global $xtraffic_TestMySQL_MySQL_I_Connection;
	global $xtraffic_TestMySQL_MySQL_Connection;
	
	if($xtraffic_TestMySQL_PDOConnection) {
		$xtraffic_TestMySQL_PDOConnection = NULL;
		unset($xtraffic_TestMySQL_PDOConnection);$xtraffic_TestMySQL_PDOConnection = '';
	}
	
	if($xtraffic_TestMySQL_MySQL_I_Connection) {
		mysqli_close($xtraffic_TestMySQL_MySQL_I_Connection);
		$xtraffic_TestMySQL_MySQL_I_Connection = NULL;
		unset($xtraffic_TestMySQL_MySQL_I_Connection);$xtraffic_TestMySQL_MySQL_I_Connection = '';
	}
	
	if($xtraffic_TestMySQL_MySQL_Connection) {
		mysql_close($xtraffic_TestMySQL_MySQL_Connection);
		$xtraffic_TestMySQL_MySQL_Connection = NULL;
		unset($xtraffic_TestMySQL_MySQL_Connection);$xtraffic_TestMySQL_MySQL_Connection = '';
	}
	
}



function xtraffic_TestMySQL_DbDropTables() 
{
	$arrayTables = array(
		'xtr_testtb_a'
		,'xtr_testtb_b'
	);
	
	foreach($arrayTables as $table) {
		if($table) {
			$queryString = '';
			$queryString = 
		'
DROP TABLE `'.$table.'`;
		';
			xtraffic_TestMySQL_DbQuery($queryString);
			
		}
	}
	
}

function xtraffic_TestMySQL_DbPrepare() 
{
	
	xtraffic_TestMySQL_DbDropTables();
	
	
	
	$queryString = '';
	$queryString = 
'

CREATE TABLE `xtr_testtb_a` (
`xtr_testcol_id`  int(8) UNSIGNED NOT NULL AUTO_INCREMENT ,
`xtr_testcol_title`  varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_content`  text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_hash`  varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ,
`xtr_testcol_date`  date NULL ,
`xtr_testcol_datetime`  datetime NULL ,
`xtr_testcol_timestamp`  timestamp NULL ON UPDATE CURRENT_TIMESTAMP ,
`xtr_testcol_bigint`  bigint(18) UNSIGNED NULL ,
`xtr_testcol_tinyint`  tinyint(2) NULL ,
`xtr_testcol_float`  float NULL ,
`xtr_testcol_double`  double NULL ,
`xtr_testcol_longtext`  longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_varchar_noind`  varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_varchar_hasind`  varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
PRIMARY KEY (`xtr_testcol_id`),
UNIQUE INDEX `ind1` (`xtr_testcol_hash`) ,
INDEX `ind2` (`xtr_testcol_title`) ,
INDEX `ind3` (`xtr_testcol_varchar_hasind`) 
);

';
	xtraffic_TestMySQL_DbQuery($queryString);
	
	
	$queryString = '';
	$queryString = 
'

CREATE TABLE `xtr_testtb_b` (
`xtr_testcol_id`  int(8) UNSIGNED NOT NULL AUTO_INCREMENT ,
`xtr_testcol_id_a`  int(8) UNSIGNED NULL ,
`xtr_testcol_title`  varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_content`  text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_hash`  varchar(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL ,
`xtr_testcol_date`  date NULL ,
`xtr_testcol_datetime`  datetime NULL ,
`xtr_testcol_timestamp`  timestamp NULL ON UPDATE CURRENT_TIMESTAMP ,
`xtr_testcol_bigint`  bigint(18) UNSIGNED NULL ,
`xtr_testcol_tinyint`  tinyint(2) NULL ,
`xtr_testcol_float`  float NULL ,
`xtr_testcol_double`  double NULL ,
`xtr_testcol_longtext`  longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_varchar_noind`  varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
`xtr_testcol_varchar_hasind`  varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL ,
PRIMARY KEY (`xtr_testcol_id`),
UNIQUE INDEX `ind1` (`xtr_testcol_hash`) ,
INDEX `ind2` (`xtr_testcol_title`) ,
INDEX `ind3` (`xtr_testcol_varchar_hasind`) ,
INDEX `ind4` (`xtr_testcol_id_a`)
);

';
	xtraffic_TestMySQL_DbQuery($queryString);
	
}



function xtraffic_TestMySQL_CleanValueQuery($input_data) 
{
	$input_data = preg_replace('#[\'\"]+#is','',$input_data);
	$input_data = xtraffic_ReduceSpace($input_data);
	return $input_data;
}

function xtraffic_TestMySQL_TestInsert($input_number_rows) 
{
	global $gbLipsumPatternTest;
	global $gbStringPatternTest;
	global $gbStringPatternTestALL;
	global $gbLevel;
	
	$stringPatternTestALLClean = $gbStringPatternTestALL;
	$stringPatternTestALLClean = xtraffic_TestMySQL_CleanValueQuery($stringPatternTestALLClean);
	
	$input_number_rows = abs((int)$input_number_rows);
	
	
	
	$resultData = array(
		'number_rows' => $input_number_rows
		,'time_spend' => 0
	);
	
	
	
	$arrayLongtext = array();
	for($x=0;$x<6;$x++) {
		$arrayLongtext[] = $stringPatternTestALLClean;
	}
	
	$arrayLongtext = implode(PHP_EOL,$arrayLongtext);
	$arrayLongtext = xtraffic_ReduceSpace($arrayLongtext);
	$arrayLongtext = explode(PHP_EOL,$arrayLongtext);
	
	$time_start = microtime(true);
	
	for($i=0;$i<$input_number_rows;$i++) {
		
		shuffle($arrayLongtext);
		
		$queryString = '';
		$queryString = 
'
INSERT INTO `xtr_testtb_a` (
	`xtr_testcol_title`
	, `xtr_testcol_content`
	, `xtr_testcol_hash`
	, `xtr_testcol_date`
	, `xtr_testcol_datetime`
	, `xtr_testcol_timestamp`
	, `xtr_testcol_bigint`
	, `xtr_testcol_tinyint`
	, `xtr_testcol_float`
	, `xtr_testcol_double`
	, `xtr_testcol_longtext`
	, `xtr_testcol_varchar_noind`
	, `xtr_testcol_varchar_hasind`
) VALUES (
	"'.xtraffic_RandomHash().' '.xtraffic_RandomHash().'"
	, "'.$stringPatternTestALLClean.'"
	, "'.xtraffic_RandomHash().'"
	, "'.date('Y-m-d',(time() - (mt_rand(0,3650) * 86400))).'"
	, "'.date('Y-m-d H:i:s',(time() - (mt_rand(0,3650) * 86400))).'"
	, "'.date('Y-m-d H:i:s',(time() - (mt_rand(0,3650) * 86400))).'"
	, "'.mt_rand().'"
	, "'.mt_rand(0,99).'"
	, "'.(1/(mt_rand()+1)).'"
	, "'.(1/(mt_rand()+1)).'"
	, "'.implode(PHP_EOL,$arrayLongtext).'"
	, "'.xtraffic_RandomHash().' '.xtraffic_RandomHash().'"
	, "'.xtraffic_RandomHash().' '.xtraffic_RandomHash().'"
);

';
		xtraffic_TestMySQL_DbQuery($queryString);
		
	}
	
	
	
	$resultData['time_spend'] = microtime(true) - $time_start;
	
	$resultData['time_spend_average_record'] = $resultData['time_spend']/$input_number_rows;
	
	
	$numRows1 = $input_number_rows / 2; 
	$numRows1 = ceil($numRows1);
	
	for($i=0;$i<$numRows1;$i++) {
		
		shuffle($arrayLongtext);
		
		$queryString = '';
		$queryString = 
'
INSERT INTO `xtr_testtb_b` (
	`xtr_testcol_id_a`
	,`xtr_testcol_title`
	, `xtr_testcol_content`
	, `xtr_testcol_hash`
	, `xtr_testcol_date`
	, `xtr_testcol_datetime`
	, `xtr_testcol_timestamp`
	, `xtr_testcol_bigint`
	, `xtr_testcol_tinyint`
	, `xtr_testcol_float`
	, `xtr_testcol_double`
	, `xtr_testcol_longtext`
	, `xtr_testcol_varchar_noind`
	, `xtr_testcol_varchar_hasind`
) VALUES (
	"'.mt_rand(1,$input_number_rows).'"
	, "'.xtraffic_RandomHash().' '.xtraffic_RandomHash().'"
	, "'.$stringPatternTestALLClean.'"
	, "'.xtraffic_RandomHash().'"
	, "'.date('Y-m-d',(time() - (mt_rand(0,3650) * 86400))).'"
	, "'.date('Y-m-d H:i:s',(time() - (mt_rand(0,3650) * 86400))).'"
	, "'.date('Y-m-d H:i:s',(time() - (mt_rand(0,3650) * 86400))).'"
	, "'.mt_rand().'"
	, "'.mt_rand(0,99).'"
	, "'.(1/(mt_rand()+1)).'"
	, "'.(1/(mt_rand()+1)).'"
	, "'.implode(PHP_EOL,$arrayLongtext).'"
	, "'.xtraffic_RandomHash().' '.xtraffic_RandomHash().'"
	, "'.xtraffic_RandomHash().' '.xtraffic_RandomHash().'"
);

';
		xtraffic_TestMySQL_DbQuery($queryString);
		
	}
	
	
	
	return $resultData;
}


function xtraffic_TestMySQL_TestSelect() 
{
	$resultData = array(
		'total_rows' => 0
		,'time_spend' => 0
		,'time_spend_average_request' => 0
	);
	
	
	$arrayTimesSpend = array();
	
	$time_start = microtime(true);
	
	$queryString = '';
	$queryString = 
'
SELECT COUNT(*) AS number_counted FROM `xtr_testtb_a`;
';
	$rsDbQuery1 = xtraffic_TestMySQL_DbParseResult(xtraffic_TestMySQL_DbQuery($queryString));
	if($rsDbQuery1) {
		if(isset($rsDbQuery1[0]['number_counted']) && $rsDbQuery1[0]['number_counted']) {
			$rsDbQuery1[0]['number_counted'] = (int)$rsDbQuery1[0]['number_counted'];
			if($rsDbQuery1[0]['number_counted']>0) {
				
				$resultData['total_rows'] = $rsDbQuery1[0]['number_counted'];
				
			}
		}
	}
	
	$arrayTimesSpend[$queryString] = abs(microtime(true) - $time_start);
	
	
	
	
	
	$arrayQueryStringsNeedTest = array(
	);
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a`;
';
	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_id` = '.mt_rand(0, $resultData['total_rows']).' ;
';
	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_title` LIKE "%'.substr(xtraffic_RandomHash(),0,2).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_content` LIKE "%'.substr(xtraffic_RandomHash(),0,1).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_hash` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,3).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_hash` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,3).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_date` >= "'.date('Y-m-d',(time() - (3660 * 86400))).'";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_datetime` >= "'.date('Y-m-d H:i:s',(time() - (3660 * 86400))).'";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_timestamp` >= "'.date('Y-m-d H:i:s',(time() - (3660 * 86400))).'";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_bigint` >= 0;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_tinyint` >= 0;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_float` >= 0;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_double` >= 0;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_longtext` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,2).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_longtext` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,2).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_varchar_noind` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,2).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_varchar_noind` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,2).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_varchar_hasind` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,2).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
WHERE `xtr_testcol_varchar_hasind` NOT LIKE "%'.substr(xtraffic_RandomHash(),0,2).'%";
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY RAND()
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY RAND()
LIMIT 0,20
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_id`
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_id` DESC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_id` ASC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_noind`
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_noind` DESC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_noind` ASC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_hasind`
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_hasind` DESC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_hasind` ASC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_hasind`,`xtr_testcol_varchar_noind`
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_hasind`,`xtr_testcol_varchar_noind` DESC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = ''; 
	$queryString = 
'
SELECT `xtr_testcol_id` FROM `xtr_testtb_a` 
ORDER BY `xtr_testcol_varchar_hasind`,`xtr_testcol_varchar_noind` ASC
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT xtr_testtb_a.xtr_testcol_id AS xtr_testcol_id_tba, xtr_testtb_b.xtr_testcol_id AS xtr_testcol_id_tbb
FROM xtr_testtb_a
LEFT JOIN xtr_testtb_b
ON xtr_testtb_a.xtr_testcol_id=xtr_testtb_b.xtr_testcol_id_a;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT xtr_testtb_a.xtr_testcol_id AS xtr_testcol_id_tba, xtr_testtb_b.xtr_testcol_id AS xtr_testcol_id_tbb
FROM xtr_testtb_b
LEFT JOIN xtr_testtb_a
ON xtr_testtb_a.xtr_testcol_id=xtr_testtb_b.xtr_testcol_id_a;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT xtr_testtb_a.xtr_testcol_id AS xtr_testcol_id_tba, xtr_testtb_b.xtr_testcol_id AS xtr_testcol_id_tbb
FROM xtr_testtb_a
RIGHT JOIN xtr_testtb_b
ON xtr_testtb_a.xtr_testcol_id=xtr_testtb_b.xtr_testcol_id_a;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT xtr_testtb_a.xtr_testcol_id AS xtr_testcol_id_tba, xtr_testtb_b.xtr_testcol_id AS xtr_testcol_id_tbb
FROM xtr_testtb_b
RIGHT JOIN xtr_testtb_a
ON xtr_testtb_a.xtr_testcol_id=xtr_testtb_b.xtr_testcol_id_a;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT xtr_testtb_a.xtr_testcol_id AS xtr_testcol_id_tba, xtr_testtb_b.xtr_testcol_id AS xtr_testcol_id_tbb
FROM xtr_testtb_a
INNER JOIN xtr_testtb_b
ON xtr_testtb_a.xtr_testcol_id=xtr_testtb_b.xtr_testcol_id_a;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	$queryString = '';
	$queryString = 
'
SELECT xtr_testtb_a.xtr_testcol_id AS xtr_testcol_id_tba, xtr_testtb_b.xtr_testcol_id AS xtr_testcol_id_tbb
FROM xtr_testtb_b
INNER JOIN xtr_testtb_a
ON xtr_testtb_a.xtr_testcol_id=xtr_testtb_b.xtr_testcol_id_a;
';

	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	$queryString = '';
	$queryString = 
'
(SELECT xtr_testtb_a.xtr_testcol_id FROM xtr_testtb_a)
UNION
(SELECT xtr_testtb_b.xtr_testcol_id FROM xtr_testtb_b)
;
';

	$arrayQueryStringsNeedTest[] = $queryString; 
	
	
	
	
	$arrayQueryStringsNeedTest = array_unique($arrayQueryStringsNeedTest);
	foreach($arrayQueryStringsNeedTest as $queryString1) {
		$time_start1 = microtime(true);
		xtraffic_TestMySQL_DbQuery($queryString1);
		$arrayTimesSpend[$queryString1] = abs(microtime(true) - $time_start1);
		
	}
	
	
	
	foreach($arrayTimesSpend as $value1) {
		$resultData['time_spend'] += $value1;
	}
	
	
	
	$resultData['time_spend_average_request'] = $resultData['time_spend']/count($arrayTimesSpend);
	
	return $resultData;
	
}




function xtraffic_TestMySQL_TestUpdate() 
{
	$resultData = array(
		'total_rows' => 0
		,'time_spend' => 0
		,'time_spend_average_request' => 0
	);
	
	
	$arrayTimesSpend = array();
	
	$arrayQueryStringsNeedTest = array(
	);
	
	
	
	
	$queryString = '';
	$queryString = 
'
UPDATE `xtr_testtb_a`
SET `xtr_testcol_bigint` = `xtr_testcol_bigint` + 1 ;
';
	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
UPDATE `xtr_testtb_a`
SET `xtr_testcol_bigint` = `xtr_testcol_bigint` + 1 
WHERE xtr_testcol_id >= 0 ;
';
	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$queryString = '';
	$queryString = 
'
UPDATE `xtr_testtb_a`
SET `xtr_testcol_bigint` = `xtr_testcol_bigint` + 1, `xtr_testcol_float` = `xtr_testcol_float` / 2
WHERE xtr_testcol_id >= 0 ;
';
	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	
	
	
	$arrayQueryStringsNeedTest = array_unique($arrayQueryStringsNeedTest);
	foreach($arrayQueryStringsNeedTest as $queryString1) {
		$time_start1 = microtime(true);
		xtraffic_TestMySQL_DbQuery($queryString1);
		$arrayTimesSpend[$queryString1] = abs(microtime(true) - $time_start1);
		
	}
	
	
	
	foreach($arrayTimesSpend as $value1) {
		$resultData['time_spend'] += $value1;
	}
	
	$resultData['time_spend_average_request'] = $resultData['time_spend']/count($arrayTimesSpend);
	
	return $resultData;
	
}




function xtraffic_TestMySQL_TestDelete() 
{
	$resultData = array(
		'total_rows' => 0
		,'time_spend' => 0
		,'time_spend_average_request' => 0
	);
	
	
	$arrayTimesSpend = array();
	
	$arrayQueryStringsNeedTest = array(
	);
	
	
	$queryString = '';
	$queryString = 
'
DELETE FROM `xtr_testtb_a`
WHERE xtr_testcol_id >= 0 ;
';
	$arrayQueryStringsNeedTest[] = $queryString;
	
	
	
	$arrayQueryStringsNeedTest = array_unique($arrayQueryStringsNeedTest);
	foreach($arrayQueryStringsNeedTest as $queryString1) {
		$time_start1 = microtime(true);
		xtraffic_TestMySQL_DbQuery($queryString1);
		$arrayTimesSpend[$queryString1] = abs(microtime(true) - $time_start1);
		
	}
	
	
	
	foreach($arrayTimesSpend as $value1) {
		$resultData['time_spend'] += $value1;
	}
	
	$resultData['time_spend_average_request'] = $resultData['time_spend']/count($arrayTimesSpend);
	
	return $resultData;
	
}






function xtraffic_TestMySQL_GetDbConnection() 
{
	global $xtraffic_Configs;
	
	global $xtraffic_TestMySQL_PDOConnection;
	global $xtraffic_TestMySQL_MySQL_I_Connection;
	global $xtraffic_TestMySQL_MySQL_Connection;
	
	$resultData = array(
		'status' => 0
		,'errors' => false
	);
	
	if(
		(isset($xtraffic_Configs['test_mysql']['configs']['server']) && $xtraffic_Configs['test_mysql']['configs']['server'])
		&& (isset($xtraffic_Configs['test_mysql']['configs']['username']) && $xtraffic_Configs['test_mysql']['configs']['username'])
		&& (isset($xtraffic_Configs['test_mysql']['configs']['database_name']) && $xtraffic_Configs['test_mysql']['configs']['database_name'])
	) {
		if(!isset($xtraffic_Configs['test_mysql']['configs']['password'])) {
			$xtraffic_Configs['test_mysql']['configs']['password'] = '';
		}
		
		if(class_exists('PDO')) {
			try {
				$dsn = 'mysql:dbname='.$xtraffic_Configs['test_mysql']['configs']['database_name'].';host='.$xtraffic_Configs['test_mysql']['configs']['server'].'';
				
				$user = $xtraffic_Configs['test_mysql']['configs']['username'];
				$password = $xtraffic_Configs['test_mysql']['configs']['password'];
				
				$dbh = new PDO($dsn, $user, $password, array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES "utf8"'
				));
				if($dbh) {
					$resultData['status'] = 1;
					$xtraffic_TestMySQL_PDOConnection = $dbh;
					$xtraffic_TestMySQL_PDOConnection->query('SET NAMES "utf8"');
				} else {
					$resultData['errors'][] = 'Database connection failed!';
				}
				
			} catch (PDOException $e) {
				$resultData['errors'][] = 'Database connection failed : ' . $e->getMessage();
			}
		} else if(function_exists('mysqli_connect')) {
			$link = mysqli_connect(
				$xtraffic_Configs['test_mysql']['configs']['server']
				,$xtraffic_Configs['test_mysql']['configs']['username']
				,$xtraffic_Configs['test_mysql']['configs']['password']
				,$xtraffic_Configs['test_mysql']['configs']['database_name']
			);
			if($link) {
				$resultData['status'] = 1;
				$xtraffic_TestMySQL_MySQL_I_Connection = $link;
				mysqli_query($xtraffic_TestMySQL_MySQL_I_Connection, 'SET NAMES "utf8"');
			} else {
				$resultData['errors'][] = 'Database connection failed : ' . mysqli_error($link);
			}
		} else if(function_exists('mysql_connect')) {
			$link = mysql_connect(
				$xtraffic_Configs['test_mysql']['configs']['server']
				,$xtraffic_Configs['test_mysql']['configs']['username']
				,$xtraffic_Configs['test_mysql']['configs']['password']
				,false
			);
			if($link) {
				if(mysql_select_db($xtraffic_Configs['test_mysql']['configs']['database_name'],$link)) {
					$resultData['status'] = 1;
					$xtraffic_TestMySQL_MySQL_Connection = $link;
					mysql_set_charset('utf8',$xtraffic_TestMySQL_MySQL_Connection);
					mysql_query('SET NAMES "utf8"',$xtraffic_TestMySQL_MySQL_Connection);
					
				} else {
					$resultData['errors'][] = 'Can\'t connect database "'.$xtraffic_Configs['test_mysql']['configs']['database_name'].'"';
					mysql_close($link);
				}
				
			} else {
				$resultData['errors'][] = 'Database connection failed : ' . mysql_error();
				mysql_close($link);
			}
		} else {
			$resultData['errors'][] = 'Your host not support database connect';
		}
	
	}
	
	if(
		$resultData['errors']
	) {
		$resultData['errors'] = array_unique($resultData['errors']);
	}
	
	return $resultData;
}


function xtraffic_TestMySQL() 
{

	global $gbPublicConfigsData;
	global $xtraffic_Configs;
	global $strPadNum1;
	global $strAllPadNum;
	global $gbLevel;
	
	$resultData = '';
	
	if(
		(isset($xtraffic_Configs['test_mysql']['configs']['server']) && $xtraffic_Configs['test_mysql']['configs']['server'])
		&& (isset($xtraffic_Configs['test_mysql']['configs']['username']) && $xtraffic_Configs['test_mysql']['configs']['username'])
		&& (isset($xtraffic_Configs['test_mysql']['configs']['database_name']) && $xtraffic_Configs['test_mysql']['configs']['database_name'])
	) {
		if(!isset($xtraffic_Configs['test_mysql']['configs']['password'])) {
			$xtraffic_Configs['test_mysql']['configs']['password'] = '';
		}
		
		$time_start = microtime(true);
		
		$rsGetDbConnection = xtraffic_TestMySQL_GetDbConnection();
		if($rsGetDbConnection['status']) {
			
			$rsGetDbConnectionTimeSpend = microtime(true) - $time_start; 
		
			$rsStr1 = str_pad('+ DB CONNECTION TIME                    : '.number_format($rsGetDbConnectionTimeSpend, 8, '.', '').' seconds', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1; 
			
			
			
			xtraffic_TestMySQL_DbPrepare();
			
			$rsTestInsert = xtraffic_TestMySQL_TestInsert(10000 * $gbLevel);
			$rsTestSelect = xtraffic_TestMySQL_TestSelect();
			$rsTestSelect2 = xtraffic_TestMySQL_TestSelect();
			$rsTestSelect3 = xtraffic_TestMySQL_TestSelect();
			$rsTestUpdate = xtraffic_TestMySQL_TestUpdate();
			$rsTestDelete = xtraffic_TestMySQL_TestDelete(); 
			
			
			$rsStr1 = str_pad('+ TEST INSERT TO DB    "'.number_format($rsTestSelect['total_rows'], 0, '.', ',').' RECORDS" : '.number_format($rsTestInsert['time_spend'], 8, '.', '').' seconds', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			$rsStr1 = str_pad('+ TEST SELECT (1) WITH "'.number_format($rsTestSelect['total_rows'], 0, '.', ',').' RECORDS" : '.number_format($rsTestSelect['time_spend'], 8, '.', '').' seconds', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			$rsStr1 = str_pad('+ TEST SELECT (2) WITH "'.number_format($rsTestSelect2['total_rows'], 0, '.', ',').' RECORDS" : '.number_format($rsTestSelect2['time_spend'], 8, '.', '').' seconds', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			$rsStr1 = str_pad('+ TEST SELECT (3) WITH "'.number_format($rsTestSelect3['total_rows'], 0, '.', ',').' RECORDS" : '.number_format($rsTestSelect3['time_spend'], 8, '.', '').' seconds', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			$rsStr1 = str_pad('+ TEST UPDATE     WITH "'.number_format($rsTestSelect['total_rows'], 0, '.', ',').' RECORDS" : '.number_format($rsTestUpdate['time_spend'], 8, '.', '').' seconds', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			$rsStr1 = str_pad('+ TEST DELETE     WITH "'.number_format($rsTestSelect['total_rows'], 0, '.', ',').' RECORDS" : '.number_format($rsTestDelete['time_spend'], 8, '.', '').' seconds', $strPadNum1).PHP_EOL;
			$resultData .= $rsStr1;
			
			$totalTime = $rsGetDbConnectionTimeSpend + $rsTestInsert['time_spend'] + $rsTestSelect['time_spend'] + $rsTestSelect2['time_spend'] + $rsTestSelect3['time_spend'] + $rsTestUpdate['time_spend'] + $rsTestDelete['time_spend'];
			
			
			$rsStr1 = str_pad('-', ceil($strAllPadNum/4) , '-') . PHP_EOL . '* '.str_pad('Total time ', $strPadNum1) . ' : ' . number_format($totalTime, 8, '.', ',') . ' seconds.'.PHP_EOL;
			$resultData .= $rsStr1;

			
			xtraffic_TestMySQL_DbDropTables();
			
		} else {
			if(
				$rsGetDbConnection['errors']
			) {
				foreach($rsGetDbConnection['errors'] as $error) {
					$rsStr1 = str_pad('+ ERROR DB : "'.trim($error).'"', $strPadNum1).PHP_EOL; 
					$resultData .= $rsStr1;
				}
			}
		}
		
		
		xtraffic_TestMySQL_CloseDbConnection();
		
		
	}
	
	return $resultData;
}
