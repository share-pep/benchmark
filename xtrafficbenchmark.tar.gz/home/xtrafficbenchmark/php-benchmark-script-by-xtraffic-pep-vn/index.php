<?php

@ini_set('memory_limit', '8192M');	//Set max memory ram is number MB 
@ini_set('max_execution_time', 86400);	//Set max execution time is number Second 
@set_time_limit(86400);
@date_default_timezone_set('Europe/London');

define('XTRAFFIC_VERSION', '2.1'); //x.x

require_once(__DIR__ . '/configs.php');
require_once(__DIR__ . '/inc/php-benchmark-script-by-xtraffic-pep-vn.class.php');

if(!isset($_SERVER['SERVER_NAME'])) {
	$_SERVER['SERVER_NAME'] = 'xtraffic.xyz';
}

if(!isset($_SERVER['SERVER_ADDR'])) {
	$_SERVER['SERVER_ADDR'] = '127.0.0.1';
}

$strAllPadNum = 110;
$strPadNum1 = $strAllPadNum - 25;  
$total = 0;
$functions = get_defined_functions();
$line = str_pad('-',$strAllPadNum,'-');
echo '<pre>',PHP_EOL,$line
	,PHP_EOL,'|'.str_pad('PHP BENCHMARK SCRIPT BY XTRAFFIC.XYZ',($strAllPadNum-2),' ',STR_PAD_BOTH).'|'
	,PHP_EOL,'|'.str_pad('VERSION '.XTRAFFIC_VERSION,($strAllPadNum-2),' ',STR_PAD_BOTH).'|'
	,PHP_EOL,'|'.str_pad('DOWNLOAD HERE : https://bit.ly/php-benchmark-script-by-xtraffic-pep-vn',($strAllPadNum-2),' ',STR_PAD_BOTH).'|'
	,PHP_EOL,'|'.str_pad('Copyright 2014 http://xtraffic.xyz , All rights reserved!',($strAllPadNum-2),' ',STR_PAD_BOTH).'|'
	,PHP_EOL,$line
	,PHP_EOL,'Start       : '.date('Y-m-d H:i:s')
	,PHP_EOL,'Server      : ',$_SERVER['SERVER_NAME'],'@',$_SERVER['SERVER_ADDR'],''
	,PHP_EOL,'PHP version : ',PHP_VERSION
	,PHP_EOL,'Platform    : ',PHP_OS
	,PHP_EOL,'Test level  : ',$gbLevel
	,PHP_EOL,$line,PHP_EOL;

	
$checkScriptIsRunning_Timeout = 600;	//seconds

$filePathCheckScriptIsRunning = __DIR__ . '/php-benchmark-script-by-xtraffic-pep-vn-is-running.txt';

$isScriptRunningStatus = false;
if(is_file($filePathCheckScriptIsRunning)) {
	if(filemtime($filePathCheckScriptIsRunning) + $checkScriptIsRunning_Timeout > time()) {
		$isScriptRunningStatus = true;
	} else {
		@unlink($filePathCheckScriptIsRunning);
	}
}

if($isScriptRunningStatus) {
	echo PHP_EOL . str_pad('ERROR : THIS SCRIPT IS RUNNING BY YOU OR OTHERS ONE. PLEASE TRY AGAIN AFTER '.$checkScriptIsRunning_Timeout.' SECONDS!',($strAllPadNum-2),' ',STR_PAD_BOTH),PHP_EOL;
	
	echo PHP_EOL . str_pad('-', ceil($strAllPadNum/1) , '-') . PHP_EOL;
	
	echo '</pre>';exit();
}

@file_put_contents($filePathCheckScriptIsRunning, 'mdft-'.time());

echo str_pad('CPU TESTED',($strAllPadNum-2),' ',STR_PAD_BOTH),PHP_EOL,PHP_EOL;

if($xtraffic_Configs['test_cpu']) {
	foreach ($functions['user'] as $user) {
		if (preg_match('#^xtraffic_TestCPU_#i', $user)) {
			$result = $user();
			$total += $result;
			echo '+ ',str_pad($user, $strPadNum1) . ' : ' . $result .' seconds.',PHP_EOL;
		}
	}
}

echo str_pad('-', ceil($strAllPadNum/4) , '-') . PHP_EOL . '* '.str_pad('Total time ', $strPadNum1) . ' : ' . number_format($total, 8, '.', ',') . ' seconds.'.PHP_EOL;






echo PHP_EOL . str_pad('-', ceil($strAllPadNum/1) , '-') . PHP_EOL;

echo str_pad('DATA STORAGE DEVICE (HDD/SSD) TESTED',($strAllPadNum-2),' ',STR_PAD_BOTH),PHP_EOL,PHP_EOL; 

echo xtraffic_TestDataStorageDevice();






echo PHP_EOL . str_pad('-', ceil($strAllPadNum/1) , '-') . PHP_EOL;

echo str_pad('MYSQL TESTED',($strAllPadNum-2),' ',STR_PAD_BOTH),PHP_EOL,PHP_EOL; 

echo xtraffic_TestMySQL();




echo PHP_EOL . str_pad('-', ceil($strAllPadNum/1) , '-') . PHP_EOL;

echo str_pad('NETWORK TESTED',($strAllPadNum-2),' ',STR_PAD_BOTH),PHP_EOL,PHP_EOL; 

echo xtraffic_TestNetwork();





echo PHP_EOL . str_pad('-', ceil($strAllPadNum/1) , '-') . PHP_EOL;

echo PHP_EOL . PHP_EOL;

echo '</pre>';






if(is_file($filePathCheckScriptIsRunning)) {
	@unlink($filePathCheckScriptIsRunning); 
}

