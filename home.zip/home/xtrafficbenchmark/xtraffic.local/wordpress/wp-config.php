<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

define('FS_CHMOD_FILE',0777);
define('FS_CHMOD_DIR',0777);
define('FS_METHOD', 'direct');
define('DISABLE_WP_CRON', true);
define('WP_DEBUG_DISPLAY', false);
define( 'AUTOMATIC_UPDATER_DISABLED', true );

define('WP_HOME','http://wordpress.xtraffic.local');
define('WP_SITEURL','http://wordpress.xtraffic.local');


// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'xtraffic_local_wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', '127.0.0.1');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '4wQDyp@1_R+yS!s-gG9)4i.^P9X=Z6Mi9/1vq{)4-%1-Ao_n(.eos^@HUp|lm}d<');
define('SECURE_AUTH_KEY',  ']$$;M?@E-5Rs~7|{zVH0_3O-K89 -j2mW5QbRI1jb@0wkG61Q!K.sD+l)spx!TSR');
define('LOGGED_IN_KEY',    '8-[Jh,sg[K1s3sV{LAF^70tN3W)hQ$)(D^5bQ}mR#btd0)[P_[~]2U|ki|F3#upM');
define('NONCE_KEY',        ' o&{hu27z[<+|obz0vW+S)!@Ttp~r}79||AZ,l}<^i^=[eB@D<Pl$m-6l7(URTE$');
define('AUTH_SALT',        'kLLj6Q|Bf1A`e0{`$dr).qwtnwPuf:O9SPYxlJZ=Uaw@!@/9E1:&{DwK{r(g$hBk');
define('SECURE_AUTH_SALT', 'pB$;?}ta0hs5:.<4hp.b9_g*e4!ncdcCog!~%dB,43S^NO`=o+`-X$dOg#vr0Mf6');
define('LOGGED_IN_SALT',   'tkRB!d+ Oc+xEA.~5xiC?WiOW?ewnp{Q4Fo~S/Nk*Y,+NP)Eg0`R5pE+=D#[W55w');
define('NONCE_SALT',       'g%k=y2V6@xNhNn/r~%%C|%;-XKUZyj,,&X&tO-y1|L86q|yc&P$hXq1].!^$-8<]');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
