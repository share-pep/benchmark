<?php
/*
#####################################################################################
#                     PHP BENCHMARK SCRIPT BY XTRAFFIC.PEP.VN                       #
#                                                                                   #
#  Author            : xTraffic.pep.vn                                              #
#  Date              : September 18, 2014                                           #
#  Website           : http://xtraffic.pep.vn/                                      #
#  Link Download     : https://bit.ly/php-benchmark-script-by-xtraffic-pep-vn       #
#                                                                                   #
#####################################################################################
*/



define('XTRAFFIC_DEBUG', false);


$xtraffic_Configs = array
(
	
	/*
	* If you want test harder, set test_level larger 1 or set in url with parameter : index.php?test_level=2
	* @test_level (number - int) : >= 0
	*/
	'test_level' => 1
	
	/*
	* If you want to test CPU, set test_cpu => true
	*/
	,'test_cpu' => true
	
	
	/*
	* If you want to test "Data Storage Device" (HDD,SSD) , set test_data_storage_device => true
	*/
	,'test_data_storage_device' => true
	
	
	/*
	* If you want to test MySQL, you set all information below
	*/
	,'test_mysql' => array(
		'configs' => array(
			'server' => '127.0.0.1'				//address of server, you can set "127.0.0.1:3306"
			,'database_name' => 'xtraffic_local_test'	//database's name to create data for test
			,'username' => 'root'	//username to connect database
			,'password' => ''	//password to connect database
		)
	)
	
	
	
	/*
	* If you DO NOT want to test NETWORK, set target => "" 
	*/
	,'test_network' => array(
		/*
		*	@target (string) : "main", "all", ""
		*
		*/
		'target' => 'main'
		
		/*
		*	@max_number_download (number - int) : >= 0
		*	0 : unlimited
		*/
		,'max_number_download' => 0
	)
	
	
	
	
	
);

?>